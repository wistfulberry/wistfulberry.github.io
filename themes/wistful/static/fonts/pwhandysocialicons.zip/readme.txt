
This font is a Donationware
and was created by http://www.peax-webdesign.com 

--------------------------------------------------------------------------

To use it on a website, you have to make a donation of your choice to :
Paypal Id : michel.lun@free.fr

--------------------------------------------------------------------------


Follow me on Facebook www.facebook.com/pages/Peax-Webdesign/358656367486305 
and G+ plus.google.com/103595703505477716588 
for news about future fonts. 


-------------------------------------------------------------------------- 